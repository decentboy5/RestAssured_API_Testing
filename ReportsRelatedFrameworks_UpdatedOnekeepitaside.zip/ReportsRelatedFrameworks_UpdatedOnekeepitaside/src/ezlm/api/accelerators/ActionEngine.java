
package ezlm.api.accelerators;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import ezlm.api.report.CReporter;
import ezlm.api.report.ReporterConstants;
import io.restassured.response.Response;

// TODO: Auto-generated Javadoc
/**
 * The Class ActionEngine.
 */
public class ActionEngine {

	// **********************************************//
	// public class ActionEngine extends TestEngineWeb {

	boolean proceedExecution = false;
	/** The Constant LOG. */
	// private static final Logger LOG = Logger.getLogger(TestEngineWeb.class);

	/** The Driver. */
	public WebDriver Driver = null;

	/** The reporter. */
	public static CReporter reporter = null;

	/** The browser. */
	/* cloud platform */
	public String browser = null;

	/** The version. */
	public String version = null;

	/** The platform. */
	public String platform = null;

	/** The environment. */
	public String environment = null;

	/** The local base url. */
	public String localBaseUrl = null;

	/** The cloud base url. */
	public String cloudBaseUrl = null;

	/** The user name. */
	public String userName = null;

	/** The access key. */
	public String accessKey = null;

	/** The cloud implicit wait. */
	public String cloudImplicitWait = null;

	/** The cloud page load time out. */
	public String cloudPageLoadTimeOut = null;

	/** The update jira. */
	public String updateJira = null;

	/** The build number. */
	public String buildNumber = "";

	/** The job name. */
	public String jobName = "";

	/** The executed from. */
	public String executedFrom = null;

	/** The url . */
	public String urlRem = "DEMO App";

	/** Test Environment URL **/
	public String Application_URL = null;
	public String urlOpcs = null;

	@BeforeClass
	// @Parameters({"browser","browserVersion","environment","platformName"})
	// public void Helloooo(String browser, String browserVersion,String
	// environment,String platformName) throws IOException, InterruptedException
	public void BeforeClass() throws IOException, InterruptedException {
		String platformName = "flotform";
		String environment = "local";
		String browser = "Firefox";
		String browserVersion = "34";
		if (environment.equalsIgnoreCase("local")) {
			// setWebDriverForLocal(browser);
		}

		reporter = CReporter.getCReporter(browser, browserVersion, environment, true);

		Application_URL = ReporterConstants.MYURL;

	}

	/**
	 * After test. - Close Driver & Reporter instance
	 *
	 * @throws Exception
	 *             the exception
	 */
	@AfterTest

	public void afterTest() throws Exception {

		// Driver.quit();
		// reporter.calculateSuiteExecutionTime();
		if (urlRem.equalsIgnoreCase("DEMO App")) {
			reporter.createHtmlSummaryReport(this.urlOpcs, true);
		}

		reporter.closeSummaryReport();
	}

	/**
	 * Before method.
	 *
	 * @param method
	 *            the method
	 */
	@BeforeMethod

	public void beforeMethod(Method method) {

		// get browser info
		// reporter = CReporter.getCReporter(deviceName, platformName, platformVersion,
		// true);
		reporter.initTestCase(this.getClass().getName().substring(0, this.getClass().getName().lastIndexOf(".")),
				method.getName(), "FIT", false);

	}

	/**
	 * After method.
	 *
	 * @throws IOException
	 *             Signals that an I/O exception has occurred.
	 */
	@AfterMethod

	public void afterMethod() throws IOException {
		// get browser info
		reporter.calculateTestCaseExecutionTime();
		reporter.closeDetailedReport();
		reporter.updateTestCaseStatus();
	}

	public void setWebdriverForGrid(String browser, String nodeUrl) throws MalformedURLException {
		DesiredCapabilities caps = new DesiredCapabilities();
		if (browser.equalsIgnoreCase("IE")) {
			caps = DesiredCapabilities.internetExplorer();
			// caps.setPlatform(Platform.ANY);
		} else if (browser.equalsIgnoreCase("Firefox")) {
			caps = DesiredCapabilities.firefox();
			// caps.setBrowserName("firefox");
			// caps.setVersion("33.0");
			caps.setPlatform(Platform.WINDOWS);
		} else if (browser.equalsIgnoreCase("chrome")) {
			caps = DesiredCapabilities.chrome();
			// caps.setPlatform(Platform.ANY);
		} else {
			caps = DesiredCapabilities.safari();
			// caps.setPlatform(Platform.ANY);
		}
		// String Node = "http://172.16.14.172:5555/wd/hub";
		// URL commandExecutorUri = new URL("http://ondemand.saucelabs.com/wd/hub");
		this.Driver = new RemoteWebDriver(new URL(nodeUrl), caps);
	}

	/*
	 * Browser Initialization
	 */
	private void setWebDriverForLocal(String browser) throws IOException, InterruptedException {

		if (browser.equalsIgnoreCase("Firefox")) {
			// Driver=new FirefoxDriver();
			String s;
			s = System.getProperty("user.dir") + "\\driver\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\driver\\chromedriver.exe");

			DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("test-type");
			options.addArguments("--start-maximized");
			options.addArguments("--ignore-certificate-errors");
			capabilities.setJavascriptEnabled(true);
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			Driver = new ChromeDriver(capabilities);
			// Driver = new FirefoxDriver();
		}

	}

	/**
	 * Sets the remote web driver for cloud sauce labs.
	 *
	 * @throws MalformedURLException
	 *             the malformed url exception
	 */
	private void setRemoteWebDriverForCloudSauceLabs() throws MalformedURLException {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability(CapabilityType.BROWSER_NAME, this.browser);
		desiredCapabilities.setCapability(CapabilityType.VERSION, this.version);
		desiredCapabilities.setCapability(CapabilityType.PLATFORM, this.platform);
		desiredCapabilities.setCapability("username", this.userName);
		desiredCapabilities.setCapability("accessKey", this.accessKey);
		desiredCapabilities.setCapability("name",
				this.executedFrom + " - " + this.jobName + " - " + this.buildNumber + " - ");
		URL commandExecutorUri = new URL("http://ondemand.saucelabs.com/wd/hub");
		this.Driver = new RemoteWebDriver(commandExecutorUri, desiredCapabilities);
	}

	/**
	 * Update configuration for cloud sauce labs jenkins.
	 */
	private void updateConfigurationForCloudSauceLabsJenkins() {
		this.browser = System.getenv("SELENIUM_BROWSER");
		this.version = System.getenv("SELENIUM_VERSION");
		this.platform = System.getenv("SELENIUM_PLATFORM");
		this.userName = System.getenv("SAUCE_USER_NAME");
		this.accessKey = System.getenv("SAUCE_API_KEY");
		this.buildNumber = System.getenv("BUILD_NUMBER");
		this.jobName = System.getenv("JOB_NAME");

		/* For Debug Purpose */
		LOG.info("Debug: browser = " + this.browser);
		LOG.info("Debug: version = " + this.version);
		LOG.info("Debug: platform = " + this.platform);
		LOG.info("Debug: userName = " + this.userName);
		LOG.info("Debug: accessKey = " + this.accessKey);
		LOG.info("Debug: executedFrom = " + this.executedFrom);
		LOG.info("Debug: BUILD_NUMBER = " + this.buildNumber);
		LOG.info("Debug: jobName = " + this.jobName);
	}

	// ********************************//

	/** The Constant LOG. */
	private static final Logger LOG = Logger.getLogger(ActionEngine.class);

	/** The msg click success. */
	private final String msgClickSuccess = "Successfully Clicked On ";

	/** The msg click failure. */
	private final String msgClickFailure = "Unable To Click On ";

	/** The msg type success. */
	private final String msgTypeSuccess = "Successfully Typed On ";

	/** launch Browser. */
	private final String browser_url = "Successfully launched the  ";

	/** The msg type failure. */
	private final String msgTypeFailure = "Unable To Type On ";

	/** The msg is element found success. */
	private final String msgIsElementFoundSuccess = "Successfully Found Element ";

	/** The msg is element found failure. */
	private final String msgIsElementFoundFailure = "Unable To Found Element ";

	/**
	 * Setdriver.
	 *
	 * @param driver
	 *            the driver
	 * @param reporter
	 *            the reporter
	 */
	/*
	 * public void setdriver(WebDriver driver,CReporter reporter) { this.Driver =
	 * driver; this.reporter = reporter;
	 * 
	 * }
	 */

	/**
	 * Click.
	 *
	 * @param locator
	 *            the locator
	 * @param locatorName
	 *            the locator name
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean click(By locator, String locatorName) throws Throwable {
		boolean status = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			this.Driver.findElement(locator).click();
			this.reporter.SuccessReport("Click", this.msgClickSuccess + locatorName);
			status = true;
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
			this.reporter.failureReport("Click", this.msgClickFailure + locatorName, this.Driver);

		}
		return status;

	}

	/**
	 * Checks if is element present.
	 *
	 * @param by
	 *            the by
	 * @param locatorName
	 *            the locator name
	 * @param expected
	 *            the expected
	 * @return true, if is element present
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean isElementPresent(By by, String locatorName, boolean expected) throws Throwable {
		boolean status = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(by));
			this.Driver.findElement(by);
			this.reporter.SuccessReport("isElementPresent", this.msgIsElementFoundSuccess + locatorName);
			status = true;
		} catch (Exception e) {
			status = false;
			LOG.info(e.getMessage());
			if (expected == status) {
				this.reporter.SuccessReport("isElementPresent", locatorName + "is ElementPresent");
			} else {
				this.reporter.failureReport(locatorName + "is ElementPresent",
						this.msgIsElementFoundFailure + locatorName, this.Driver);
			}
		}
		return status;
	}

	/**
	 * Switch to frame.
	 *
	 * @param locator
	 *            the locator
	 * @param locatorName
	 *            the locator name
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean SwitchToFrame(By locator, String locatorName) throws Throwable {
		boolean flag = false;

		try {

			this.Driver.switchTo().defaultContent();
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			// wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name("tree")));
			this.Driver.switchTo().frame(this.Driver.findElement(locator));
			flag = true;
			return flag;

		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Switch to Frame", "Switch to Frame failed" + locatorName);

			} else if (flag == true) {
				this.reporter.SuccessReport("Switch to Frame", "Switch to Frame done" + locatorName);
			}
		}

	}

	/**
	 * Type.
	 *
	 * @param locator
	 *            the locator
	 * @param testdata
	 *            the testdata
	 * @param locatorName
	 *            the locator name
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean launch() throws Throwable {
		boolean status = true;
		Driver.get(Application_URL);
		Driver.manage().window().maximize();
		reporter.calculateSuiteStartTime();
		this.reporter.SuccessReport("launch", this.browser_url + Application_URL);
		return status;
	}

	public boolean uriinfo_Attach_Toreport(String URI) {
		boolean status = true;
		/*
		 * Driver.get(Application_URL); Driver.manage().window().maximize();
		 * reporter.calculateSuiteStartTime();
		 */
		reporter.SuccessReport("Request URI", URI);
		return status;
	}

	public void headerinfo_Attach_Toreport(HashMap<String, String> headers) {
		// TODO Auto-generated method stub
		String completeHeader = "";
		// this.reporter.SuccessReport("Headers :" , "");
		Set<Entry<String, String>> headersset = headers.entrySet();
		Iterator<Entry<String, String>> _headers = headersset.iterator();
		while (_headers.hasNext()) {
			Entry<String, String> data = _headers.next();
			String HeaderKey = data.getKey();
			String HeaderValue = data.getValue();
			completeHeader = completeHeader + HeaderKey + ":" + HeaderValue + "<br>";

		}
		reporter.SuccessReport("Headers", completeHeader);

	}

	public static void validateresponse(String key, String actual, String expected) throws Throwable {

		if (expected.startsWith("length:")) {
			expected = expected.substring(7);
			if (!actual.equalsIgnoreCase("0"))
				actual = String.valueOf(actual.length());
		}
		if (actual.isEmpty()) {
			reporter.SuccessReport("Validations :", "Expected Value for <b>" + key + "</b> is <b>{}</b> ");
		} else if (actual.equals("notpresent")) {
			reporter.failureReport("Validations :", "Expected Value for <b>" + key + "</b> = <b><font color=\"red\">"
					+ expected + "</font></b> is not present in the response ");
		} else if (!actual.equalsIgnoreCase(expected)) {
			reporter.failureReport("Validations :", "Expected Value for <b>" + key + "</b> in  response is : <b>"
					+ expected + "</b>   But Actual value is :<b><font color=\"red\">" + actual + "</font></b>");
		} else {
			reporter.SuccessReport("Validations :",
					"Expected Value for <b>" + key + "</b> in  response is : <b><font color=\"green\">\"" + expected
							+ "\"</b></font>  And Actual value is :<b>\"<font color=\"green\">" + actual
							+ "</font>\"</b>");
		}
	}

	public void responseStatusCode(int actual_Statuscode) throws Throwable {
		String _actual_Statuscode = String.valueOf(actual_Statuscode);
		reporter.SuccessReport("Status Code", _actual_Statuscode);
	}

	protected static void verifyContentinResponse(String content, boolean flag) throws Throwable {
		if (flag) {
			reporter.SuccessReport("Validation",
					"<b><font color=\"green\">" + content + "</font></b> is Present in the Response body");
		} else {
			reporter.failureReport("Response",
					"<b><font color=\"red\">" + content + "</font></b> is Not Present in the Response body");
		}

	}

	public void responsefromserver_Attach_toReport(Response response)   {
		// TODO Auto-generated method stub
		reporter.SuccessReport("Response", response.getBody().asString());

		if (response.getStatusLine().contains("500")) {
			try {
				reporter.failureReport("Status Line", "<font color=\"red\">"+response.getStatusLine()+"</font>");
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			reporter.SuccessReport("Status Line", response.getStatusLine());
		}
		if (String.valueOf(response.getStatusCode()).contains("500")) {
			try {
				reporter.SuccessReport("Status Code", "<font color=\"red\">"+String.valueOf(response.getStatusCode())+"</font>");
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			reporter.SuccessReport("Status Code", String.valueOf(response.getStatusCode()));
		}
		reporter.SuccessReport("Response Headers", response.getHeaders().asList().toString());

	}

	public void responsefromserver_exception_Attach_ToReport(String error) {

		try {
			reporter.failureReport("Exception :",
					"Exception while hitting the server is :<b><font color=\"red\">" + error + "</font></b>");
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void requestBody(String requestBody) throws Throwable {
		// TODO Auto-generated method stub
		reporter.SuccessReport("Request Body", requestBody);

	}

	public boolean type(By locator, String testdata, String locatorName) throws Throwable {
		boolean status = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			this.Driver.findElement(locator).clear();
			this.Driver.findElement(locator).sendKeys(testdata);
			this.reporter.SuccessReport("type", this.msgTypeSuccess + locatorName);
			status = true;
		} catch (Exception e) {
			status = false;
			e.printStackTrace();
			LOG.info(e.getMessage());
			this.reporter.failureReport("type", this.msgTypeFailure + locatorName, this.Driver);
		}

		return status;
	}

	/**
	 * Moves the mouse to the middle of the element. The element is scrolled into
	 * view and its location is calculated using getBoundingClientRect.
	 *
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:link,menus etc..)
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean mouseover(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			WebElement mo = this.Driver.findElement(locator);
			new Actions(this.Driver).moveToElement(mo).build().perform();
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("MouseOver", "MouseOver action is not perform on" + locatorName,
						this.Driver);

			} else if (flag == true) {

				this.reporter.SuccessReport("MouseOver", "MouserOver Action is Done on" + locatorName);
			}
		}
	}

	/**
	 * Tab.
	 *
	 * @param locator
	 *            the locator
	 * @param locatorName
	 *            the locator name
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean tab(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			WebElement mo = this.Driver.findElement(locator);
			mo.sendKeys(Keys.TAB);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Tab", "Tab action is not perform on " + locatorName, this.Driver);

			} else if (flag == true) {

				this.reporter.SuccessReport("Tab", "Tab Action is Done on " + locatorName);
			}
		}
	}

	/**
	 * JS click.
	 *
	 * @param locator
	 *            the locator
	 * @param locatorName
	 *            the locator name
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean JSClick(By locator, String locatorName) throws Throwable {

		boolean flag = false;
		try {
			if (!this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("safari")) {
				WebDriverWait wait = new WebDriverWait(this.Driver, 60);
				wait.until(ExpectedConditions.elementToBeClickable(locator));
				WebElement element = this.Driver.findElement(locator);
				JavascriptExecutor executor = (JavascriptExecutor) this.Driver;
				executor.executeScript("arguments[0].click();", element);
				// driver.executeAsyncScript("arguments[0].click();", element);

				flag = true;
			} else {
				WebDriverWait wait = new WebDriverWait(this.Driver, 60);
				wait.until(ExpectedConditions.elementToBeClickable(locator));
				this.Driver.findElement(locator).click();
				this.reporter.SuccessReport("Click", this.msgClickSuccess + locatorName);
				flag = true;
			}
		}

		catch (Exception e) {

		} finally {
			if (flag == false) {
				this.reporter.failureReport("Click", "MouseOver action is not perform on" + locatorName);
				return flag;
			} else if (flag == true) {
				this.reporter.SuccessReport("Click", "MouserOver Action is Done on" + locatorName);
				return flag;
			}
		}
		return flag;

	}

	/**
	 * Wait for element present.
	 *
	 * @param by
	 *            the by
	 * @param locator
	 *            the locator
	 * @param secs
	 *            the secs
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean waitForElementPresent(By by, String locator, int secs) throws Throwable {
		boolean status = false;

		try {

			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(by));
			for (int i = 0; i < secs / 2; i++) {
				List<WebElement> elements = this.Driver.findElements(by);
				if (elements.size() > 0) {
					status = true;
					return status;

				} else {
					this.Driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
				}
			}

		} catch (Exception e) {

			return status;
		}

		return status;

	}

	/**
	 * Assert text on element.
	 *
	 * @param by
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param text
	 *            : expected text to assert on the element
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:link text, label text etc..)
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean verifyText(By by, String text, String locatorName) throws Throwable {
		boolean flag = false;

		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(by));
			String vtxt = getText(by, locatorName).trim();
			if (vtxt.equalsIgnoreCase(text.trim())) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("VerifyText", text + " is not present in the location" + locatorName);
				flag = false;
			} else if (flag == true) {
				this.reporter.SuccessReport("VerifyText", text + " is present in the location " + locatorName);
				flag = true;
			}
		}
		return flag;

	}

	/**
	 * The innerText of this element.
	 *
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:label text, SignIn Link
	 *            etc..)
	 * @return the text
	 * @throws Throwable
	 *             the throwable
	 * @return: String return text on element
	 */

	public String getText(By locator, String locatorName) throws Throwable {
		String text = "";
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			if (isElementPresent(locator, locatorName, true)) {
				text = this.Driver.findElement(locator).getText();
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (flag == false) {
				this.reporter.warningReport("GetText", "Unable to get Text from" + locatorName);
			} else if (flag == true) {
				this.reporter.SuccessReport("GetText", "Able to get Text from" + locatorName);
			}
		}
		return text;
	}

	/*
	 * public static int getResponseCode(String url) { try { return
	 * Request.Get(url).execute().returnResponse().getStatusLine() .getStatusCode();
	 * } catch (Exception e) { throw new RuntimeException(e); } }
	 */
	/**
	 * This method verify check box is checked or not.
	 *
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:sign in Checkbox etc..)
	 * @return true, if is checked
	 * @throws Throwable
	 *             the throwable
	 * @return: boolean value(True: if it is checked, False: if not checked)
	 */
	public boolean isChecked(By locator, String locatorName) throws Throwable {
		boolean bvalue = false;
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			if (this.Driver.findElement(locator).isSelected()) {
				flag = true;
				bvalue = true;
			}
		} catch (NoSuchElementException e) {

			bvalue = false;
		} finally {
			if (flag == true) {
				this.reporter.SuccessReport("IsChecked", locatorName + " is Selected");
				// throw new ElementNotFoundException("", "", "");

			} else if (flag == false) {
				this.reporter.failureReport("IsChecked", locatorName + " is not Select");
			}
		}
		return bvalue;
	}

	/**
	 * Verify alert present or not.
	 *
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 * @return: Boolean (True: If alert preset, False: If no alert)
	 */
	public boolean AlertAccept() throws Throwable {
		boolean flag = false;
		try {

			// Check the presence of alert
			org.openqa.selenium.Alert alert = this.Driver.switchTo().alert();
			// if present consume the alert
			alert.accept();
			flag = true;
		} catch (NoAlertPresentException ex) {
			// Alert present; set the flag

			// Alert not present
			ex.printStackTrace();
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Alert", "There was no alert to handle");
			} else if (flag == true) {
				this.reporter.SuccessReport("Alert", "The Alert is handled successfully");
			}
		}

		return flag;
	}

	/**
	 * Verify alert present or not for Safari.
	 *
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 * @return: Boolean (True: If alert preset, False: If no alert)
	 */
	public boolean JSAcceptAlert() throws Throwable {

		boolean flag = false;
		try {
			JavascriptExecutor executor = (JavascriptExecutor) this.Driver;
			executor.executeScript("confirm = function(message){return true;};");
			executor.executeScript("alert = function(message){return true;};");
			executor.executeScript("prompt = function(message){return true;}");
			flag = true;

		}

		catch (Exception e) {

		} finally {
			if (flag == false) {
				this.reporter.failureReport("Accept Alert", "Alert Accept performed ");
				return flag;
			} else if (flag == true) {
				this.reporter.SuccessReport("Accept Alert", "Alert Accept performed ");
				return flag;
			}
		}
		return flag;

	}

	/**
	 * Verify alert present or not.
	 *
	 * @param filePath
	 *            the file path
	 * @param locator
	 *            the locator
	 * @param locatorName
	 *            the locator name
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 * @return: Boolean (True: If alert preset, False: If no alert)
	 */
	public boolean uploadFile(String filePath, By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			click(locator, locatorName);
			Thread.sleep(5000);
			Actions KeyboardEvent = new Actions(this.Driver);
			KeyboardEvent.sendKeys(filePath);
			Thread.sleep(1000);
			KeyboardEvent.sendKeys(Keys.ENTER);

		} catch (NoAlertPresentException ex) {
			// Alert present; set the flag

			// Alert not present
			ex.printStackTrace();
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Alert", "There was no alert to handle");
			} else if (flag == true) {
				this.reporter.SuccessReport("Alert", "The Alert is handled successfully");
			}
		}

		return flag;
	}

	/**
	 * Select a value from Dropdown using send keys.
	 *
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param value
	 *            : Value wish type in dropdown list
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Year Dropdown, items Listbox
	 *            etc..)
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean selectBySendkeys(By locator, String value, String locatorName) throws Throwable {

		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			if (this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("ie")
					|| this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("safari")) {
				this.Driver.findElement(locator).click();
				Select drp = new Select(this.Driver.findElement(locator));
				drp.selectByVisibleText(value);
			} else {
				this.Driver.findElement(locator).sendKeys(value);
			}
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Select", value + "is Not Select from the DropDown " + locatorName);
				// throw new ElementNotFoundException("", "", "");

			} else if (flag == true) {
				this.reporter.SuccessReport("Select", value + " is Selected from the DropDown " + locatorName);
			}
		}
	}

	/**
	 * select value from DropDown by using selectByIndex.
	 *
	 * @param locator
	 *            : Action to be performed on element (Get it from Object
	 *            repository)
	 * @param index
	 *            : Index of value wish to select from dropdown list.
	 * @param locatorName
	 *            : Meaningful name to the element (Ex:Year Dropdown, items Listbox
	 *            etc..)
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean selectByIndex(By locator, int index, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			Select s = new Select(this.Driver.findElement(locator));
			s.selectByIndex(index);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Select",
						"Option at index " + index + " is Not Select from the DropDown" + locatorName);

			} else if (flag == true) {
				this.reporter.SuccessReport("Select",
						"Option at index " + index + "is Selected from the DropDown" + locatorName);
			}
		}
	}

	/**
	 * Switch to.
	 *
	 * @param url
	 *            the url
	 * @return true, if successful
	 * @throws Throwable
	 *             the throwable
	 */
	public boolean switchTo(String url) throws Throwable {
		boolean flag = false;
		try {
			Driver.navigate().to(url);
			flag = true;
		} catch (NoAlertPresentException ex) {
			// Alert present; set the flag

			// Alert not present
			ex.printStackTrace();
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Alert", "There was no alert to handle");
			} else if (flag == true) {
				this.reporter.SuccessReport("Alert", "The Alert is handled successfully");
			}
		}

		return flag;

	}

	public boolean enter(By locator, String locatorName) throws Throwable {
		boolean flag = false;
		try {
			WebDriverWait wait = new WebDriverWait(this.Driver, 60);
			wait.until(ExpectedConditions.elementToBeClickable(locator));
			WebElement mo = this.Driver.findElement(locator);
			mo.sendKeys(Keys.ENTER);
			Thread.sleep(2000);
			flag = true;
			return true;
		} catch (Exception e) {

			return false;
		} finally {
			if (flag == false) {
				this.reporter.failureReport("Enter", "Tab action is not perform on " + locatorName, this.Driver);

			} else if (flag == true) {

				this.reporter.SuccessReport("Enetr", "Tab Action is Done on " + locatorName);
			}
		}
	}

	public String strwithtimestamp(String str) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();
		String strDateStamp = dateFormat.format(date);
		strDateStamp = ((strDateStamp.replace(" ", "_")).replace("/", "_")).replace(":", "_");

		return str + strDateStamp;
	}

	public void FilterCheck(By Filter_Locator, By Grid_Locator, String Value) throws Throwable {
		type(Filter_Locator, Value, "Filter");
		if (this.reporter.getBrowserContext().getBrowserName().equalsIgnoreCase("safari")) {
			enter(Filter_Locator, "presss the Enter key");
			Thread.sleep(5000);
		} else {
			tab(Filter_Locator, "presss the Enter key");
			Thread.sleep(5000);
		}
		String Str_optionset_name = getText(Grid_Locator, "Name");
		if (Value.equals(Str_optionset_name)) {
			boolean validationPoint = isElementPresent(Grid_Locator, "Optionset name", true);
			if (validationPoint) {
				this.reporter.SuccessReport("User is able to verify Optionset name from grid",
						"User is able to verify Optionset name from grid");
			} else {
				this.reporter.failureReport("User is not able to verify Optionset name from grid",
						"User is not able to verify Optionset name from grid", this.Driver);
			}
		}
	}
}