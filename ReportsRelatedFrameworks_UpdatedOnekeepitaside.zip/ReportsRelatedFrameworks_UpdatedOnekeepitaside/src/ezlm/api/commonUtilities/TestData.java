package ezlm.api.commonUtilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class TestData {
	//static Properties props = new Properties();
	static String propertyFile;
	static String strValue;
	private static String _classname=TestData.class.getSimpleName();
	
	public static final String Environment=Config.getProperty("TLMConfigurations", "Environment");



	/**
	 * getProperty : Used to get the Values from from Our Configuration file. *
	 * 
	 * @param :
	 *            strKey - Any Property Name Mentioned in
	 *            TLMConfiguration.properties File
	 */
	public static String getProperty(String path) {
		try {			
			//System.out.println("helooo");
			//Properties props = new Properties();
			// String[] property;
			//System.out.println(path.toString());
			String newPath = new String(path);
			String property=newPath.split("#")[1];
			String testDataFolder=newPath.split("#")[0];
			String configFileName;
			Properties props = new Properties();
			
			configFileName = System.getProperty("user.dir") + "\\Testdata\\"+Environment+"\\"+testDataFolder+"\\" + _classname + ".properties";
			
		
			
			
			File f = new File(configFileName);
			if (f.exists()) {
				FileInputStream in = new FileInputStream(f);
				props.load(in);
				strValue = props.getProperty(property);
				in.close();
			} else
				System.out.println("File not found!");
		} catch (Exception e) {
			System.out.println(e);
		}
		return strValue;
	}

	


	public void getClassName()
	{
		String propertyFileName = "/dynamicelements/" + getClass().getSimpleName().toLowerCase()
				+ "_dynamicelements.properties";
		
		System.out.println(propertyFileName);
	}

	/**
	 * setProperty : Used to Modify the Values from from Our Configuration file.
	 * *
	 * 
	 * @param :
	 *            strKey - Any Property Name Mentioned in
	 *            TLMConfiguration.properties File
	 * @param :
	 *            strValue - new value for the existing keys
	 */
/*	public void setProperty(String strKey, String strValue) throws Throwable {
		try {
			File f = new File(propertyFile);
			if (f.exists()) {
				FileInputStream in = new FileInputStream(f);
				props.load(in);
				props.setProperty(strKey, strValue);
				props.store(new FileOutputStream(propertyFile), null);
				in.close();
			} else {
				System.out.println("File not found!");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	
	
	*//**
	 * RemoveProperty : Used to Modify the Values from from Our Configuration file.
	 * *
	 * 
	 * @param :
	 *            strKey - Any Property Name Mentioned in
	 *            TLMConfiguration.properties File
	 * @param :
	 *            strValue - new value for the existing keys
	 *//*
	public void removeProperty(String strKey) {
		try {
			File f = new File(propertyFile);
			if (f.exists()) {
				FileInputStream in = new FileInputStream(f);
				props.load(in);
				props.remove(strKey);
				props.store(new FileOutputStream(propertyFile), null);
				in.close();
			} else
				System.out.println("File not found!");
		} catch (Exception e) {
			System.out.println(e);
		}

	}*/

}
