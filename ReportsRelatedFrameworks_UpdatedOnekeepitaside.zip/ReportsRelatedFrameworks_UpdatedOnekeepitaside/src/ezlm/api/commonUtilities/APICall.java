package ezlm.api.commonUtilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.testng.Assert;

import ezlm.api.accelerators.ActionEngine;
import ezlm.api.businessMethods.Clocks;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APICall extends ActionEngine{
	
	
	public static HashMap<String, String> headers = null;
	public static Logger log = Logger.getLogger(APICall.class);

	public static String Get_ResponseBody(String uri, HashMap<String, String> headers) {
		String responseBody = null;
		try {

			RestAssured.baseURI = uri;
			RequestSpecification httpRequest = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				httpRequest.header(data.getKey(), data.getValue());
			}

			Response response = httpRequest.request(Method.GET, "/paycode");

			responseBody = response.getBody().asString();
			return responseBody;

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return responseBody;
	}
/***
 * It's a Get API call. it requires URI, resource and headers to get the response. and return type is Response
 * @param uri  : URI of the Get Call
 * @param headers  : Headers for Get call
 * @param ParameterORqueryParam  : you can pass Parameter or QueryParam
 * @return
 */
	public Response api_Getcall(String uri,HashMap<String, String> headers, String ParameterORqueryParam)  {
		Response response = null;

		try {

		
			
			if(ParameterORqueryParam.startsWith("{"))				
			{
				
				String formatted_Queryparam="";		
				String[] Queryparam_array;
				String  queryparam= "{expand=details,filter=10001,expand=details,filter=10001}";
				
				//StringBuilder _queryparam=new StringBuilder(queryparam); 
				
				if(!ParameterORqueryParam.contains(","))
				{
					formatted_Queryparam=ParameterORqueryParam.replaceAll("[{}]", "").trim();
					formatted_Queryparam="$"+formatted_Queryparam;			
				}
				else
				{
					Queryparam_array=ParameterORqueryParam.replaceAll("[{}]", "").trim().split(",");
					for (int i = 0; i < Queryparam_array.length; i++) {
						
						formatted_Queryparam=formatted_Queryparam+"$"+Queryparam_array[i]+"&";
						
					}
					formatted_Queryparam=formatted_Queryparam.substring(0, formatted_Queryparam.length()-1);
					
				}
				ParameterORqueryParam="?"+formatted_Queryparam;
				System.out.println(uri+ParameterORqueryParam);
				uriinfo_Attach_Toreport(uri+ParameterORqueryParam);
			}
			/*else
			{
				uriinfo_Attach_Toreport(uri+ParameterORqueryParam);
			}*/
			log.info("Given URI    :    " + uri);
			log.info("Headers      :   " + headers);
			uriinfo_Attach_Toreport(uri+ParameterORqueryParam);
			headerinfo_Attach_Toreport(headers);
			
			RestAssured.baseURI = uri;
			//RestAssured.basePath="PayCode_API88494";
		
			

			RequestSpecification httpRequest = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				String HeaderKey = data.getKey();
				String HeaderValue = data.getValue();
				if (HeaderKey == null)
					HeaderKey = "";
				if (HeaderValue == null)
					HeaderValue = "";
				httpRequest.header(HeaderKey, HeaderValue);
				
			}
		//	httpRequest.get("PayCode_API88494");
			
			if(ParameterORqueryParam.startsWith("?")){
				response = httpRequest.get(uri+ParameterORqueryParam);
			}
			else
			{
				response = httpRequest.request(Method.GET,ParameterORqueryParam);
			}
			
			
			log.info("API Response    :   \n" + response.getBody().asString());
			responsefromserver_Attach_toReport(response);
			System.out.println(response.getBody().asString());
			return response;
		} catch (Exception e) {
			responsefromserver_exception_Attach_ToReport(e.toString());
			Assert.fail("Error whlie hitting the server :"+e.toString());
			System.out.println(e.getMessage());
			System.out.println(e);
		}
		return response;
	}

	
	/**
	 * It's a Get API call. it requires URI, resource and headers to get the response. and return type is Response. 
	 * 
	 * @param uri
	 * @param resource
	 * @param headers
	 * @return
	 * @throws Throwable 
	 */
	public Response api_Getcall(String uri, HashMap<String, String> headers)  {
		Response response = null;

		try {

			log.info("Given URI    :    " + uri);
			log.info("Headers      :   " + headers);
			uriinfo_Attach_Toreport(uri);
			headerinfo_Attach_Toreport(headers);
			
			RestAssured.baseURI = uri;
			//RestAssured.basePath="PayCode_API88494";
		
			

			RequestSpecification httpRequest = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				String HeaderKey = data.getKey();
				String HeaderValue = data.getValue();
				if (HeaderKey == null)
					HeaderKey = "";
				if (HeaderValue == null)
					HeaderValue = "";
				httpRequest.header(HeaderKey, HeaderValue);
				
			}
		//	httpRequest.get("PayCode_API88494");
			
			response = httpRequest.request(Method.GET);
			log.info("API Response    :   \n" + response.getBody().asString());
			responsefromserver_Attach_toReport(response);
			System.out.println(response.getBody().asString());
			return response;
		} catch (Exception e) {
			responsefromserver_exception_Attach_ToReport(e.toString());
			Assert.fail("Error whlie hitting the server :"+e.toString());
			System.out.println(e.getMessage());
			System.out.println(e);
		}
		return response;
	}

	
	/**
	 * It's a Get API call. it requires URI, resource and headers to get the response. and return type is Response. 
	 * 
	 * @param uri
	 * @param resource
	 * @param headers
	 * @return
	 * @throws Throwable 
	 */
	@SuppressWarnings("deprecation")
	public Response api_Getcall(String uri, HashMap<String, Object>  queryparam, String resource, HashMap<String, String> headers)  {
		Response response = null;

		try {

			log.info("Given URI    :    " + uri);
			log.info("Headers      :   " + headers);
			uriinfo_Attach_Toreport(uri+resource);
			headerinfo_Attach_Toreport(headers);
			
			//RestAssured.basePath = uri;
			RestAssured.baseURI = uri;
			//RestAssured.basePath="PayCode_API88494";

			
			RequestSpecification httpRequest = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				String HeaderKey = data.getKey();
				String HeaderValue = data.getValue();
				if (HeaderKey == null)
					HeaderKey = "";
				if (HeaderValue == null)
					HeaderValue = "";
				httpRequest.header(HeaderKey, HeaderValue);
				
			}
			response=httpRequest.queryParams(queryparam).when().get();
			
			httpRequest.get();
			log.info("API Response    :   \n" + response.getBody().asString());
			responsefromserver_Attach_toReport(response);
			System.out.println(response.getBody().asString());
			return response;
		} catch (Exception e) {
			responsefromserver_exception_Attach_ToReport(e.toString());
			Assert.fail("Error whlie hitting the server :"+e.toString());
			System.out.println(e.getMessage());
			System.out.println(e);
		}
		return response;
	}

	public Response api_PostCall(String uri,HashMap<String, String> headers,String body) {
		Response response = null;

		String resource = "";
		try {

			log.info("Given URI     :    " + uri);
			log.info("Headers      :   " + headers);
			try {
				uriinfo_Attach_Toreport(uri+resource);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				headerinfo_Attach_Toreport(headers);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			RestAssured.baseURI = uri;
			RequestSpecification request = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				request.header(data.getKey(), data.getValue());
			}
			try {
				requestBody(body);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.body(body);
			response = request.post(resource);
			//request.body(PayCode.AddPayCodeBody("nonworked", "payCodeRate"));
			//response = request.post("/paycode.add");
			try {
				responsefromserver_Attach_toReport(response);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response body: " + response.body().asString());
			return response;
		} catch (Exception e) 
		{
				responsefromserver_exception_Attach_ToReport(e.toString());
				Assert.fail("Error whlie hitting the server :"+e.toString());
	
		}
		return response;
	}


	public Response api_PostCall(String uri,String resource, HashMap<String, String> headers,String body) {
		Response response = null;

		try {

			log.info("Given URI     :    " + uri);
			log.info("Headers      :   " + headers);
			try {
				uriinfo_Attach_Toreport(uri+resource);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				headerinfo_Attach_Toreport(headers);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			RestAssured.baseURI = uri;
			RequestSpecification request = RestAssured.given();

			Set<Entry<String, String>> headersset = headers.entrySet();
			Iterator<Entry<String, String>> _headers = headersset.iterator();
			while (_headers.hasNext()) {
				Entry<String, String> data = _headers.next();
				request.header(data.getKey(), data.getValue());
			}
			try {
				requestBody(body);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.body(body);
			response = request.post(resource);
			//request.body(PayCode.AddPayCodeBody("nonworked", "payCodeRate"));
			//response = request.post("/paycode.add");
			try {
				responsefromserver_Attach_toReport(response);
			} catch (Throwable e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("Response body: " + response.body().asString());
			return response;
		} catch (Exception e) 
		{
				responsefromserver_exception_Attach_ToReport(e.toString());
				Assert.fail("Error whlie hitting the server :"+e.toString());
	
		}
		return response;
	}

	/***
	 * 
	 * @param response
	 *            : Response object for the API Request
	 * @param keyORXpath
	 *            : specfic key or XPATH to check in the response
	 * @param expectedvalue
	 *            The value to check in the response for the given key or XPATH
	 * 
	 */
	@SuppressWarnings("unchecked")
	public static void verify_response(Response response, String keyORXpath, String expectedvalue) {

		System.out.println(" ");
		Object responsevalue_Obj = null;
		String StringORArrayList = null;
		try {

			boolean status = false;
			System.out.println("");

			JsonPath jsonPathEvaluator = response.jsonPath();
			responsevalue_Obj = jsonPathEvaluator.get(keyORXpath);
			StringORArrayList = responsevalue_Obj.getClass().getSimpleName();
			if (StringORArrayList.toLowerCase().equals("arraylist")) {
				ArrayList<String> actualvalue_List = (ArrayList<String>) responsevalue_Obj;
				for (String _actualvalue : actualvalue_List) {

					if (_actualvalue.contains(expectedvalue)) {
						status = true;
						break;
					}
				}
				if (!status) {
					Assert.fail(expectedvalue + "           is Not present in the response body");
				}
			} else {
				responsevalue_Obj = responsevalue_Obj.toString();
				Assert.assertEquals(responsevalue_Obj, expectedvalue);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/***
	 * 
	 * @param response
	 * @param expected_StatusCode
	 */
	public static void verify_Response_StatusCode(Response response, int expected_StatusCode) {

		try {
			int actual_Statuscode = response.getStatusCode();
			Assert.assertEquals(actual_Statuscode, expected_StatusCode);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_StatusLine(Response response, String expected_StatusLine) {

		try {
			String actual_StatusLine = response.getStatusLine();
			actual_StatusLine = actual_StatusLine.trim();
			Assert.assertEquals(actual_StatusLine, expected_StatusLine);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static void verify_Response_Header(Response response, String Expected_header_name) {

		try {
			String header_Response = response.getHeader(Expected_header_name);
			if (Expected_header_name.equals("Content-Type")) {
				Assert.assertEquals(header_Response, "application/json");
			} else if (Expected_header_name.equals("Connection")) {
				Assert.assertEquals(header_Response, "Keep-Alive");
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
