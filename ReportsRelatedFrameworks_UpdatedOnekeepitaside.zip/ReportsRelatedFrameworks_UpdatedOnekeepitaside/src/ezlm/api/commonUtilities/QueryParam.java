package ezlm.api.commonUtilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

public class QueryParam {


	private static final String Environment=Config.getProperty("TLMConfigurations", "Environment");
	public static HashMap<String, String> getQueryParam(String foldername)
	{
		
		String headerfilename="Headers.properties";
		headerfilename=headerfilename.toLowerCase();
		FileInputStream file = null;
		try {
			file = new FileInputStream(System.getProperty("user.dir")+"/Testdata/"+Environment+"/"+foldername+"/"+headerfilename);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		HashMap<String,String> headers=new HashMap<String, String>();
       Properties prop=new Properties();
       try {
		prop.load(file);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
       Set<Object> keys=prop.keySet();
       
       	for (Object object : keys) {
			
       		headers.put((String) object, prop.getProperty((String) object));
		}
       	return headers;
       
	}
}
