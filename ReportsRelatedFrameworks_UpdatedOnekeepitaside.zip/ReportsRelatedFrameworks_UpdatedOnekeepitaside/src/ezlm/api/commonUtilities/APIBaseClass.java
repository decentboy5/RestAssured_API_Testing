package ezlm.api.commonUtilities;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class APIBaseClass {

/*	public static HashMap<String, String> headers = null;
	public static Logger log=Logger.getLogger(APIBaseClass.class);
	
	@BeforeMethod
	public void beforeMethod(Method method) throws IOException {

		log.info("-------------" + method.getName() + "   Started------------------------------------------------");
		log.info("                                                                                                ");

	}

	@AfterMethod
	public void afterMethod(Method method) throws IOException {

		log.info("                                                                                              ");
		log.info("--------------" + method.getName() + "   Ended------------------------------------------------");
		log.info("                                                                                              ");


	}*/
}
