package ezlm.api.commonUtilities;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.lang3.RandomStringUtils;

public class CommonMethods {

	public static void main(String[] args) {

		String utctime = geESTTime("MM.dd.yyyy hh:mma", 0);
		System.out.println(utctime);
	}

	public static String geESTTime(String format, int daystoAdd) {

		// format = "MM.dd.yyyy hh:mma";
		// daystoAdd=1;
		TimeZone timeZone = TimeZone.getTimeZone("America/New_York");
		Calendar calendar = Calendar.getInstance(timeZone);
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format, Locale.US);
		simpleDateFormat.setTimeZone(timeZone);
		calendar.add(Calendar.DATE, daystoAdd);
		// System.out.println("Time zone: " + timeZone.getID());
		// System.out.println("default time zone: " + TimeZone.getDefault().getID());
		// System.out.println();

		// System.out.println("UTC: " + simpleDateFormat.format(calendar.getTime()));
		return simpleDateFormat.format(calendar.getTime());

	}

	public static String getRandomString(int count) {

		return RandomStringUtils.random(count, true, true);

	}
	
	public static String getRanomNumber(int count) {

		return RandomStringUtils.random(count, false, true);

	}
}
