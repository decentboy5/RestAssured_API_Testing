package ezlm.api.testsuite;

public class sample {

	public static void main(String[] args) {
		
		
////$expand=details&$filter=10001
		
		
		String formatted_Queryparam="";		
		String[] Queryparam_array;
		String  queryparam= "{expand=details,filter=10001,expand=details,filter=10001}";
		
		//StringBuilder _queryparam=new StringBuilder(queryparam); 
		
		if(!queryparam.contains(","))
		{
			queryparam=queryparam.replaceAll("[{}]", "").trim();
			queryparam="$"+queryparam;			
		}
		else
		{
			Queryparam_array=queryparam.replaceAll("[{}]", "").trim().split(",");
			for (int i = 0; i < Queryparam_array.length; i++) {
				
				formatted_Queryparam=formatted_Queryparam+"$"+Queryparam_array[i]+"&";
				
			}
			formatted_Queryparam=formatted_Queryparam.substring(0, formatted_Queryparam.length()-1);
			
		}
		System.out.println(formatted_Queryparam);
		
		
	}
}
