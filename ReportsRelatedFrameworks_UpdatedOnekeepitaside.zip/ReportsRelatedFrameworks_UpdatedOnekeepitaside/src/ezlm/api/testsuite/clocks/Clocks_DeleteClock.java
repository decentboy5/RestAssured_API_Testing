package ezlm.api.testsuite.clocks;

import org.testng.annotations.Test;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class Clocks_DeleteClock extends APICall {

	@Test
	public void DeleteClock() {
		headers = Headers.getHeaders("Clocks");

		Response response = api_PostCall(Clocks.DeleteClock_Request,headers, Clocks.DeleteClock_Body());

		APIResponse.verify_response(response, "status", "success");

	}
}
