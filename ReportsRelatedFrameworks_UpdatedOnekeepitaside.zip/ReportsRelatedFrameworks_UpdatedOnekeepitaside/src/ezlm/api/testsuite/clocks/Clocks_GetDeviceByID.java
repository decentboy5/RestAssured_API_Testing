package ezlm.api.testsuite.clocks;

import org.testng.annotations.Test;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class Clocks_GetDeviceByID extends APICall{

	@Test
	public void GetDeviceByID() throws Throwable {

		// Get Headers from Property File
		headers = Headers.getHeaders("Clocks");

		
		
		// Get Call with URI and Headers
		Response response = api_Getcall(Clocks.GetDeviceById_Request,headers,Clocks.ClockName);

		// validations
		APIResponse.verify_response(response, "status", "success");
		APIResponse.verify_response(response, "data.dctId", Clocks.ClockName);
		
		
	}
}
