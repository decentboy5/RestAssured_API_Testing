package ezlm.api.testsuite.clocks;

import java.util.HashMap;

import org.testng.annotations.Test;

import ezlm.api.businessMethods.Clocks;
import ezlm.api.commonUtilities.APICall;
import ezlm.api.commonUtilities.APIResponse;
import ezlm.api.commonUtilities.Headers;
import io.restassured.response.Response;

public class Clocks_GetTimeClockProfiles extends APICall {

	@Test
	public void GetTimeclockProfile() {

		// ?$expand=details&$filter=10001
		headers = Headers.getHeaders("Clocks");

		Response response = api_Getcall(Clocks.GetTimeClockProfile_Request, headers, "{expand=details,filter=10000}");

		APIResponse.verify_response(response, "data.options.profileId", "BasicWithInOut");
	}
}
